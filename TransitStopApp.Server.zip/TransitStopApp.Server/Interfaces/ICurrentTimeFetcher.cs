﻿namespace TransitStopApp.Server.Interfaces;

public interface ICurrentTimeFetcher
{
    public TimeOnly Fetch();
}
