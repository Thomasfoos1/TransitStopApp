﻿using Microsoft.AspNetCore.Mvc;
using TransitStopApp.Server.Interfaces;
using TransitStopApp.Server.Models;

namespace TransitStopApp.Server.Controllers;

[ApiController]
[Route("api/[controller]")]
public class StopsController(ITransitStopOperations stopOperations,
    IMinuteOfDayConverter timeConverter, ICurrentTimeFetcher currentTimeFetcher)
    : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Stop>>> Get()
    {
        var stops = await stopOperations.GetAllStopsAsync();
        return Ok(stops);
    }

    [HttpGet("{stopId}/next")]
    public async Task<ActionResult<string>> GetStop(int stopId)
    {
        var currentTime = currentTimeFetcher.Fetch();
        var minuteOfDay = timeConverter.TimeOnlyToMinuteOfDay(currentTime);
        var nextStopTime = await stopOperations
            .GetNextStopTimeAsync(stopId, minuteOfDay);

        if (nextStopTime < 0)
            return NotFound("Unable to find next stop time");

        var nextStopStr = timeConverter.MinuteOfDayToTimeOnly(nextStopTime)
            .ToString("HH:mm");

        return Ok(new { nextStop = nextStopStr });
    }
}