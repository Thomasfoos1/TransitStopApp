using Microsoft.EntityFrameworkCore;
using TransitStopApp.Server.Interfaces;
using TransitStopApp.Server.Utility;

var builder = WebApplication.CreateBuilder(args);
var dbConnStr = builder.Configuration["TransitStopDbConnString"]
    ?? throw new InvalidOperationException("TransitStopDbConnString is not configured."); ;
var clientOrigin = builder.Configuration["ClientOrigin"]
    ?? throw new InvalidOperationException("ClientOrigin is not configured."); ;

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.WithOrigins(clientOrigin)
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Initialize and seed DB
await TransitStopDbInitializer.Initialize(dbConnStr);

// Register the factory
builder.Services.AddDbContextFactory<TransitStopDbContext>(options =>
    options.UseSqlite(dbConnStr));

builder.Services.AddTransient<ITransitStopOperations>(sp =>
{
    var dbFactory = sp.GetRequiredService<IDbContextFactory<TransitStopDbContext>>();
    var db = dbFactory.CreateDbContext();
    return new TransitStopOperations(db);
});

builder.Services.AddSingleton<IMinuteOfDayConverter, MinuteOfDayConverter>();
builder.Services.AddSingleton<ICurrentTimeFetcher, CurrentTimeFetcherPst>();

// Add services for controllers
builder.Services.AddControllers();

var app = builder.Build();

app.UseCors();

// Map controller endpoints
app.MapControllers();

app.Run();