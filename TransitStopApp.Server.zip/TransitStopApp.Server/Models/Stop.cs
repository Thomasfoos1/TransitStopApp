﻿namespace TransitStopApp.Server.Models;

public class Stop
{
    public int Id { get; set; }
    public required string Name { get; set; }
    public int StopOrder { get; set; }
}