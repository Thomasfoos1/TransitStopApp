﻿namespace TransitStopApp.Server.Models;

public class StopTime
{
    public int Id { get; set; }
    public int StopId { get; set; }
    public int StopMinuteOfDay { get; set; }
}
