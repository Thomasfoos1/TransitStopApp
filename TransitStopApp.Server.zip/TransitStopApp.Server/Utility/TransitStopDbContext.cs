﻿using Microsoft.EntityFrameworkCore;
using TransitStopApp.Server.Models;

namespace TransitStopApp.Server.Utility;

/// <summary>
/// EF Core DbContext for TransitStop DB. Contains tables for bus stops and 
/// their scheduled stop times. 
/// </summary>
public class TransitStopDbContext : DbContext
{
    public TransitStopDbContext(DbContextOptions options) : base(options)
    {
    }

    /// <summary>
    /// Set of bus stops in the Stop table.
    /// </summary>
    public DbSet<Stop> Stops => Set<Stop>();

    /// <summary>
    /// Set of bus stop times in the StopTime table.
    /// </summary>
    public DbSet<StopTime> StopTimes => Set<StopTime>();

    /// <summary>
    /// Configure properties, keys and indices on the models.
    /// </summary>
    /// <param name="modelBuilder"></param>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<StopTime>()
            .HasOne<Stop>()                
            .WithMany()                    
            .HasForeignKey(t => t.StopId) 
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<StopTime>()
            .HasIndex(t => new { t.StopId, t.StopMinuteOfDay })
            .HasDatabaseName("IX_StopTime_StopId_StopMinuteOfDay");
    }
}
