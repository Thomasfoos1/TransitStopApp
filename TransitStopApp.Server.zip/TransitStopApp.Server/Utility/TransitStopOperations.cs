﻿using Microsoft.EntityFrameworkCore;
using TransitStopApp.Server.Interfaces;
using TransitStopApp.Server.Models;

namespace TransitStopApp.Server.Utility;

public class TransitStopOperations(TransitStopDbContext dbContext)
    : ITransitStopOperations
{
    /// <summary>
    /// Get all stops ordered by StopOrder
    /// </summary>
    /// <returns>An IEnumerable of all stops ordered by StopOrder</returns>
    public async Task<IEnumerable<Stop>> GetAllStopsAsync()
    {
        return await dbContext.Stops
            .OrderBy(s => s.StopOrder)
            .ToListAsync();
    }

    /// <summary>
    /// Find the next stop time for a given stopId and current time.
    /// If no stop is available for the current day, find the earliest stop
    /// of the next day.
    /// </summary>
    /// <param name="stopId">ID of the stop to query</param>
    /// <param name="currentMinuteOfDay">The current time in minutes since midnight</param>
    /// <returns>An integer representing the next stop minute of day, or -1 if not found</returns>
    public async Task<int> GetNextStopTimeAsync(int stopId, int currentMinuteOfDay)
    {
        var stopTime = await dbContext.StopTimes
            .Where(t => t.StopId == stopId && t.StopMinuteOfDay > currentMinuteOfDay)
            .OrderBy(t => t.StopMinuteOfDay)
            .FirstOrDefaultAsync();

        stopTime ??= await dbContext.StopTimes
            .Where(t => t.StopId == stopId)
            .OrderBy(t => t.StopMinuteOfDay)
            .FirstOrDefaultAsync();

        return stopTime is not null ? 
            stopTime.StopMinuteOfDay : -1;
    }
}
