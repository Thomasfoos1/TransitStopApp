﻿using TransitStopApp.Server.Interfaces;

namespace TransitStopApp.Server.Utility;

public class CurrentTimeFetcherPst : ICurrentTimeFetcher
{
    public TimeOnly Fetch()
    {
        var utcNow = DateTime.UtcNow;
        var pstZone = TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time");
        var pstTime = TimeZoneInfo.ConvertTimeFromUtc(utcNow, pstZone);
        return TimeOnly.FromDateTime(pstTime);
    }
}
